---
title: Version Info
weight: 170324057
---
# Version Info

The version of NB5 which provided some of the docs content is:

```
version=5.21.2-SNAPSHOT
groupId=io.nosqlbench
artifactId=nbr
```
