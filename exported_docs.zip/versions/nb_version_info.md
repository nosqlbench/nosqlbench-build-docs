---
weight: 170324057
title: Version Info
---
# Version Info

The version of NB5 which provided some of the docs content is:

```
version=5.17.5-SNAPSHOT
groupId=io.nosqlbench
artifactId=nbr
```
